# Sevgi chat — GitHub Pages

Bu loyiha GitHub Pages + Firebase Realtime Database bilan ishlaydi.

## 1. Firebase
Firebase Console'da yangi loyiha yarating:
- Realtime Database -> Create Database
- vaqtincha test mode'dan foydalanishingiz mumkin
- Project settings -> Your apps -> Web app yarating
- berilgan firebaseConfig qiymatlarini `index.html` ichidagi `firebaseConfig` ga qo'ying

> Test mode faqat tez sinash uchun. Saytni hammaga berishdan oldin Database Rules bilan himoyalash tavsiya qilinadi.

## 2. GitHub
1. GitHub'da yangi repository yarating, masalan `sevgi-chat`.
2. `index.html` ni repository'ga yuklang.
3. Settings -> Pages -> Deploy from branch -> `main` / root.
4. Bir necha daqiqadan keyin GitHub sizga:
   `https://USERNAME.github.io/sevgi-chat/`
   kabi manzil beradi.

## 3. Ishlatish
Ikkovingiz shu bir xil linkni ochasiz.
Ism kiritasiz.
Xabar yozasiz yoki `＋` orqali rasm yuborasiz.

Rasmlar Firebase Realtime Database'ga siqilgan JPEG sifatida saqlanadi; bu tezkor/sodda variant.
